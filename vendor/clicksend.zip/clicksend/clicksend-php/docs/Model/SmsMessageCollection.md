# SmsMessageCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messages** | [**\ClickSend\Model\SmsMessage[]**](SmsMessage.md) | Array of SmsMessage items | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


