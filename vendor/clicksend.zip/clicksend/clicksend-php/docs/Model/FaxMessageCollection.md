# FaxMessageCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messages** | [**\ClickSend\Model\FaxMessage[]**](FaxMessage.md) | Array of FaxMessage items | 
**file_url** | **string** | URL of file to send | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


