# MmsMessageCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**media_file** | **string** | Media file you want to send | 
**messages** | [**\ClickSend\Model\MmsMessage[]**](MmsMessage.md) | Array of MmsMessage models | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


