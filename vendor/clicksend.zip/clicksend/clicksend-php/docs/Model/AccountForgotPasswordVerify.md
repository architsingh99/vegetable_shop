# AccountForgotPasswordVerify

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subaccount_id** | **int** | ID of subaccount | 
**activation_token** | **string** | Activation token | 
**password** | **string** | Password | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


