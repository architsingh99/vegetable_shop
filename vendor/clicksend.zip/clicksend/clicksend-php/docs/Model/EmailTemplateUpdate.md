# EmailTemplateUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template_name** | **string** | The intended name for the template. | [optional] 
**body** | **string** | Your template body. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


