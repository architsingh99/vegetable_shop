# VoiceMessageCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messages** | [**\ClickSend\Model\VoiceMessage[]**](VoiceMessage.md) | Array of VoiceMessage items | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


