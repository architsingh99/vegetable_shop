# EmailSMSAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email_address** | **string** | Your email address | 
**from** | **string** | Your sender id | 
**subaccount_id** | **string** | Your subaccount id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


