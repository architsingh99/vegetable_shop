# AccountVerify

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country** | **string** | Country code | 
**user_phone** | **string** | User&#39;s phone number | 
**type** | **string** | Type of verification | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


