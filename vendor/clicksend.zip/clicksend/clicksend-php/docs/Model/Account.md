# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | Your username | 
**password** | **string** | Your password | 
**user_phone** | **string** | Your phone number in E.164 format. | 
**user_email** | **string** | Your email | 
**user_first_name** | **string** | Your first name | 
**user_last_name** | **string** | Your last name | 
**account_name** | **string** | Your delivery to value. | 
**country** | **string** | Your country | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


