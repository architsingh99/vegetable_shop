# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_name** | **string** | Your address name. | 
**address_line_1** | **string** | Your address line 1 | 
**address_city** | **string** | Your city | 
**address_postal_code** | **string** | Your postal code | 
**address_country** | **string** | Your country | 
**address_line_2** | **string** | Your address line 2 | [optional] 
**address_state** | **string** | Your state | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


